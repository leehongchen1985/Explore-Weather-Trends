import pandas as pd
import matplotlib.pyplot as plt

# Read Temperature Data from CSV file
df = pd.read_csv('Input\\Moving_Average_Temperature_Data.csv')

#  Plotting 10 years Moving Average Temperature of Singapore and Global
plt.plot(df['Year'], df['10yrs_Moving_Average_of_Global_Temperature'],label='Global')
plt.plot(df['Year'], df['10yrs_Moving_Average_of_Singapore_Temperature'],label='Singapore', color='red')

plt.title('10 Years Moving Average Temperature Data of Singapore and Global', fontsize=25)
plt.xlabel('Year',fontsize=20)
plt.ylabel('Temperature, Celsius',fontsize=20)

plt.legend(loc='upper left',fontsize=15)
plt.show()

# Plotting 10 years Moving Average Temperature Temperature Data of Singapore
plt.plot(df['Year'], df['10yrs_Moving_Average_of_Singapore_Temperature'],label='Singapore', color='red')

plt.title('10 Years Moving Average Temperature Data of Singapore', fontsize=25)
plt.xlabel('Year',fontsize=20)
plt.ylabel('Temperature, Celsius',fontsize=20)

plt.legend(loc='upper left',fontsize=15)

plt.show()

# Plotting 10 years Moving Average Temperature Temperature Data of Global
plt.plot(df['Year'], df['10yrs_Moving_Average_of_Global_Temperature'],label='Global')

plt.title('10 Years Moving Average Temperature Data of Global', fontsize=25)
plt.xlabel('Year',fontsize=20)
plt.ylabel('Temperature, Celsius',fontsize=20)

plt.legend(loc='upper left', fontsize=15)

plt.show()